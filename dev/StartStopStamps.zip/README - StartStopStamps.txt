Script Name: StartStopStamps
Language: Python
Summary:

This script extracts the start/stop time from the trial xcp file and displays them in the Nexus log output

Dependencies (python modules, matlab toolboxes, .vst, etc.): None
Run in Vicon Nexus: Yes, this can be run as pipeline in Nexus using Nexus Python
Example data provided: None
Author: Kory Herber - Vicon Motion Systems, Inc.